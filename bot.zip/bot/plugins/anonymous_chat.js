async function handler(m, { command }) {
command = command.toLowerCase()
this.anonymous = this.anonymous ? this.anonymous : {}
switch (command) {
case 'next':
case 'leave': {
let room = Object.values(this.anonymous).find(room => room.check(m.sender))
if (!room) return this.sendButton(m.chat, '*🔒 No estas en un Chat Anonimo 🔒*\n\n*¿Quieres Iniciar Uno?*\n_da Click en el Siguiente Botón_', author, null, [['Iniciar Chat Anonimo', `.start`]], m)
m.reply('*🔓 Salió con Éxito del Chat Anonimo 🔓*')
let other = room.other(m.sender) 
if (other) await this.sendButton(other, '*🔒 El otro Usuario ha Abandonado el Chat Anonimo 🔒*\n\n*¿Quieres ir a otro Chat Anonimo?*\n_da Click en el Siguiente Botón_', author, null, [['Iniciar Chat Anonimo', `.start`]], m)
delete this.anonymous[room.id]
if (command === 'leave') break
}
case 'start': {
if (Object.values(this.anonymous).find(room => room.check(m.sender))) return this.sendButton(m.chat, '*🔒 Todavia estas en un Chat Anonimo o Esperando a que otro Usuario se Una para Iniciar*\n\n*¿Quieres Salir del Chat Anonimo?*\n_da Click en el Siguiente Botón_', author, null, [['Salir del Chat Anonimo', `.leave`]], m)
let room = Object.values(this.anonymous).find(room => room.state === 'WAITING' && !room.check(m.sender))
if (room) {
await this.sendButton(room.a, '*👤 Una Persona se ha Unido al Chat Anonimo 👤, Pueden Iniciar a Chatear*', author, null, [['ir a otro Chat', `.next`]], m)
room.b = m.sender
room.state = 'CHATTING'
await this.sendButton(m.chat, '*👤 Una Persona se ha Unido al Chat Anonimo 👤, Pueden Iniciar a Chatear*', author, null, [['ir a otro Chat', `.next`]], m)
} else {
let id = + new Date
this.anonymous[id] = {
id,
a: m.sender,
b: '',
state: 'WAITING',
check: function (who = '') {
return [this.a, this.b].includes(who)
},
other: function (who = '') {
return who === this.a ? this.b : who === this.b ? this.a : ''
},
}
await this.sendButton(m.chat, '*📍Esperando a otro Usuario para Iniciar el Chat Anonimo 📍*\n\n*¿Quieres Salir del Chat Anonimo?*\n_da Click en el Siguiente Botón_', author, null, [['Salir del Chat Anonimo', `.leave`]], m)
}
break
}}}
handler.help = ['start', 'leave', 'next']
handler.tags = ['anonymous']
handler.command = ['start', 'leave', 'next']
handler.private = true
export default handler
