import fs from 'fs'
let handler = async (m, { conn, text } ) => {  
let chats = Object.entries(conn.chats).filter(([jid, chat]) => !jid.endsWith('@g.us') && chat.isChats).map(v => v[0])
let cc = text ? m : m.quoted ? await m.getQuotedObj() : false || m
let teks = text ? text : cc.text
for (let id of chats) { 
conn.sendButton(id, `*╔══❰ COMUNICADO ❱══╗*\n*║*\n*╠❧* ${text}\n*║*\n*╚══════════════╝*`, 'ESTE ES UN COMUNICADO ESPECIAL\n' + wm, fs.readFileSync('./src/avatar_contact.png'), [['🤖 Owner 🤖', '.owner'],['💰 Donar 💰', '.donasi']], false, { 
contextInfo: { externalAdReply: {
title: 'Comunicado Especial a Chats Privados',
body: 'Netfree - Bot', 
sourceUrl: `https://github.com/netfree/`, 
thumbnail: fs.readFileSync('./Menu.png') }}})}
m.reply(`*🍒 Mensaje Enviado a 🍒 ${chats.length} Chats Privados*\n\n*Es Posible que Tenga Fallas Este Comando y No se Envíe a Todos los Chats, Disculpe por el Momento*`)
}
handler.help = ['broadcastchats', 'bcchats'].map(v => v + ' <teks>')
handler.tags = ['owner']
handler.command = /^(broadcastchats?|bcc(hats?)?)$/i
handler.rowner = true
export default handler
