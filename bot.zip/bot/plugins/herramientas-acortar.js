import fetch from 'node-fetch'
let handler = async(m, { conn, args, text }) => {
if (!text) throw '*☘️ Ingrese un Enlace/Url el Cual Desea Acortar ☘️*'
let shortUrl1 = await (await fetch(`https://tinyurl.com/api-create.php?url=${args[0]}`)).text()  
if (!shortUrl1) throw `*❗ Compruebe que el Texto Ingresado sea un Texto e Intenta de Nuevo ❗*`
let done = `*🍒 Link Acortado Correctamente 🍒*\n\n*Link Anterior:*\n${text}\n*Link Acortado:*\n${shortUrl1}`.trim()   
m.reply(done)}
handler.help = ['tinyurl','acortar'].map(v => v + ' <link>')
handler.tags = ['tools']
handler.command = /^(tinyurl|short|acortar|corto)$/i
handler.fail = null
export default handler
