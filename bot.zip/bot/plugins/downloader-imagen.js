import { googleImage } from '@bochilteam/scraper'
let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `*🍒 Ejemplo de Uso del Comando 🍒 ${usedPrefix + command} Minecraft*`
const res = await googleImage(text)
let image = await res.getRandom()
let link = image
let captionn = `🔎 *Resultado de:* ${text}\n🔗 *Link:* ${link}\n🌎 *Buscador:* Google`
conn.sendButton(m.chat, captionn, author, link, [['🔄 Siguiente 🔄', `#imagen ${text}`]], m)}
handler.help = ['gimage <query>', 'imagen <query>']
handler.tags = ['internet', 'tools']
handler.command = /^(gimage|image|imagen)$/i
export default handler
