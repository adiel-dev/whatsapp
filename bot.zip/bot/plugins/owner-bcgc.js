import fs from 'fs'
let handler = async (m, { conn, text } ) => {  
let groups = Object.entries(conn.chats).filter(([jid, chat]) => jid.endsWith('@g.us') && chat.isChats && !chat.metadata?.read_only && !chat.metadata?.announce).map(v => v[0])
let cc = text ? m : m.quoted ? await m.getQuotedObj() : false || m
let teks = text ? text : cc.text
for (let id of groups) { 
conn.sendButton(id, `*╔══❰ COMUNICADO ❱══╗*\n*║*\n*╠❧* ${text}\n*║*\n*╚══════════════╝*`, 'ESTE ES UN COMUNICADO OFICIAL\n' + wm, fs.readFileSync('./src/avatar_contact.png'), [['🤖 Owner 🤖', '.owner'],['💰 Donar 💰', '.donasi']], false, { 
contextInfo: { externalAdReply: {
title: 'Comunicado Oficial a Grupos',
body: 'Netfree - Bot', 
sourceUrl: `https://github.com/adiel-dev/bot`, 
thumbnail: fs.readFileSync('./Menu2.jpg') }}})}
m.reply(`*🍒 Mensaje Enviado a 🍒 ${groups.length} Grupo/s*\n\n*Es Posible que Tenga Fallos Este Comando y No se Envíe a Todos los Chats, Disculpe por el Momento*`)
}
handler.help = ['broadcastgroup', 'bcgc'].map(v => v + ' <teks>')
handler.tags = ['owner']
handler.command = /^(broadcast|bc)(group|grup|gc)$/i
handler.rowner = true
export default handler
