export function before(m) {
    let user = global.db.data.users[m.sender]
    if (user.afk > -1) {
        m.reply(`
  *🩸 Dejaste de Estar Inactivo 🩸${user.afkReason ? ' Después de Estar Inactivo, Por el Motivo: ' + user.afkReason : ''}*
  
  *—◉ Tiempo de Inactividad: ${(new Date - user.afk).toTimeString()}*
  `.trim())
        user.afk = -1
        user.afkReason = ''
    }
    let jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
    for (let jid of jids) {
        let user = global.db.data.users[jid]
        if (!user)
            continue
        let afkTime = user.afk
        if (!afkTime || afkTime < 0)
            continue
        let reason = user.afkReason || ''
        m.reply(`*🩸 No lo Etiquetes 🩸*

*—◉ El Usuario que Usted Etiqueto, Esta Inactivo*      
*—◉ ${reason ? 'Motivo de Inactividad: ' + reason : 'Motivo de Inactividad: _El Usuario no Especificó un Motivo_'}*
*—◉ Tiempo Transcurrido de Inactividad: ${(new Date - afkTime).toTimeString()}*
  `.trim())
    }
    return true
}
