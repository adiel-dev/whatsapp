let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `*🍒 Ingrese un Texto para Crear una Imagen y asi Usar la Función de Dall-E 🍒*\n\n*—◉ Ejemplos de Peticiones*\n*◉ ${usedPrefix + command} niños llorando*\n*◉ ${usedPrefix + command} hola hola hola*`
try {
m.reply('*🍒 Espere un momento 🍒*')
let tiores = await conn.getFile(`https://api.lolhuman.xyz/api/dall-e?apikey=${lolkeysapi}&text=${text}`)
await conn.sendFile(m.chat, tiores.data, null, null, m)
} catch {
throw `*🔒 Por Favor, Vuelva a Intentarlo 🔒*`
}}
handler.command = ['dall-e', 'dalle', 'ia2', 'cimg', 'openai2']
export default handler
