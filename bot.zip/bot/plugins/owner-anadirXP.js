import MessageType from '@adiwajshing/baileys'
let pajak = 0
let handler = async (m, { conn, text }) => {
let who
if (m.isGroup) who = m.mentionedJid[0]
else who = m.chat
if (!who) throw '*🔥 Etiqueta a Un Usuario con el @𝚝𝚊𝚐 🔥*'
let txt = text.replace('@' + who.split`@`[0], '').trim()
if (!txt) throw '*🍒 Ingresa la Cantidad de Experiencia (XP) Desea Añadir 🍒*'
if (isNaN(txt)) throw '*⚔️ Símbolo no Admitido, Sólo Números ⚔️*'
let xp = parseInt(txt)
let exp = xp
let pjk = Math.ceil(xp * pajak)
exp += pjk
if (exp < 1) throw '*🍒 El Número Mínimo de Experiencia (XP) Para Añadir es 1 🍒*'
let users = global.db.data.users
users[who].exp += xp
  m.reply(`≡ *XP Añadido*
┌──────────────
💰  *Total:* ${xp}
└──────────────`)
}
handler.command = ['añadirxp','addexp'] 
handler.rowner = true
export default handler
