import fetch from 'node-fetch'
let handler = async (m, { text, usedPrefix, command }) => {
if (!text) throw `*🔥 Ingrese Una Petición o Una Orden Para Usar la Función de ChatGpt 🔥*\n\n*—◉ Ejemplos de Peticiones y Ordenes*\n*◉ ${usedPrefix + command} que es un bot*\n*◉ ${usedPrefix + command} Código en Js para un juego de cartas*`
try {
m.reply('*🍒 Espere un Momento 🍒*')
let tiores = await fetch(`https://api.lolhuman.xyz/api/openai?apikey=${lolkeysapi}&text=${text}&user=user-unique-id`)
let hasil = await tiores.json()
m.reply(`${hasil.result}`.trim())
} catch {
throw `*🔒 Por Favor, Vuelva a Intentarlo 🔒*`
}}
handler.command = ['openai', 'chatgpt', 'ia', 'robot']
export default handler
