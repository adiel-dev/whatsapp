import { toAudio } from '../lib/converter.js'
let handler = async (m, { conn, usedPrefix, command }) => {
let q = m.quoted ? m.quoted : m
let mime = (q || q.msg).mimetype || q.mediaType || ''
if (!/video|audio/.test(mime)) throw `*🍒 Reponda al Video o Nota de Voz que Desee Convertir a Audio/Mp3 🍒*`
let media = await q.download()
if (!media) throw '*⚔️ Ocurrió un Error al Descargar su Video, Por Favor Vuelva a Intentarlo ⚔️*'
let audio = await toAudio(media, 'mp4')
if (!audio.data) throw '*⚔️ Ocurrió un Error al Convertir su Nota de Voz a Audio/Mp3, Por Favor Vuelva a Intentarlo ⚔️*'
conn.sendMessage(m.chat, { audio: audio.data,  mimetype: 'audio/mpeg' }, { quoted: m })
}
handler.alias = ['tomp3', 'toaudio']
handler.command = /^to(mp3|audio)$/i
export default handler
