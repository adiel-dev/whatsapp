import Presence from '@adiwajshing/baileys'
let handler  = async (m, { conn, args, text }) => {
if (!text) throw `*🩸 Ingrese el Nombre que Desea que sea el Nuevo Nombre del Grupo 🩸*`
try {
let text = args.join` `
if(!args || !args[0]) {
} else {
conn.groupUpdateSubject(m.chat, text)}
} catch (e) {
throw '*⚔️ Lo Siento hubo un Error, el Nombre no Puede tener mas de 25 Carácteres ⚔️*'
}}
handler.help = ['setname <text>']
handler.tags = ['group']
handler.command = /^(setname)$/i
handler.group = true
handler.admin = true
export default handler
