import fetch from 'node-fetch'
let handler = async (m, { conn, args, text }) => {
if (!text) throw '*🔒 Ingrese el Nombre de un Usuario de Tiktok 🔒*'
let res = `https://api.lolhuman.xyz/api/pptiktok/${text}?apikey=${lolkeysapi}`
conn.sendFile(m.chat, res, 'error.jpg', `*👤 Aqui esta la Foto de Perfil de ${text}*`, m, false)}
handler.help = ['tiktokfoto'].map(v => v + ' <username>')
handler.tags = ['downloader']
handler.command = /^(tiktokfoto|pptiktok)$/i
export default handler
