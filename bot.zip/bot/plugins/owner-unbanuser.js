let handler = async (m, { conn, text}) => {
if (!text) throw '*🔥 Ingresa el @𝚝𝚊𝚐 de Algún Usuario 🔥*'
let who
if (m.isGroup) who = m.mentionedJid[0]
else who = m.chat
if (!who) throw '*🔥 Ingresa el @𝚝𝚊𝚐 de Algún Usuario 🔥*'
let users = global.db.data.users
users[who].banned = false
conn.reply(m.chat, `*🍒 El Usuario fue Desbaneado con Éxito 🍒*\n*—◉ El Usuario ya Puede Usar el Bot*`, m)
}
handler.help = ['unbanuser']
handler.tags = ['owner']
handler.command = /^unbanuser$/i
handler.rowner = true
export default handler
