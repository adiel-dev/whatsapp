let handler = async (m, { conn, text, usedPrefix, command }) => {
global.db.data.sticker = global.db.data.sticker || {}
if (!m.quoted) throw '*🍒 Responde al Sticker o Imagen al Cual Desee Agregar un Comando o Texto 🍒*'
if (!m.quoted.fileSha256) throw '*🍒 Solo puedes Asignar Comandos o Textos a Stickers e Imagenes 🍒*'
if (!text) throw `*⚔️ Error, Texto Faltante ⚔️*\n\n*Uso Correcto del Comando:*\n*—◉ ${usedPrefix + command} <texto> <responder a sticker o imagen>*\n\n*Ejemplo de Uso Correcto del Comando:*\n*—◉ ${usedPrefix + command} <#menu> <responder a sticker o imagen>*`
let sticker = global.db.data.sticker
let hash = m.quoted.fileSha256.toString('base64')
if (sticker[hash] && sticker[hash].locked) throw '*🍒 Solo el Owner Puede Realizar la Modificación 🍒*'
sticker[hash] = { text, mentionedJid: m.mentionedJid, creator: m.sender, at: + new Date, locked: false }
m.reply(`*🔒 El Texto/Comando Asignado al Sticker/Imagen fue Agregado a la Base de Datos Correctamente 🔒*`)
}
handler.command = ['setcmd', 'addcmd', 'cmdadd', 'cmdset']
handler.rowner = true
export default handler
