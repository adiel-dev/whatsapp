import MessageType from '@adiwajshing/baileys'
let pajak = 0
let handler = async (m, { conn, text }) => {
let who
if (m.isGroup) who = m.mentionedJid[0]
else who = m.chat
if (!who) throw '*🔥 Etiqueta a un Usuario con el @𝚝𝚊𝚐 🔥*'
let txt = text.replace('@' + who.split`@`[0], '').trim()
if (!txt) throw '*🍒 Ingrese la Cantidad de Diamantes que Desea Añadir 🍒*'
if (isNaN(txt)) throw '*⚔️ Símbolo no Admitido, Sólo Números ⚔️*'
let dmt = parseInt(txt)
let limit = dmt
let pjk = Math.ceil(dmt * pajak)
limit += pjk
if (limit < 1) throw '*🍒 El Número Mínimo de Diamantes Para Añadir es 1 🍒*'
let users = global.db.data.users
users[who].limit += dmt
m.reply(`≄1�7 *💎 Añadido*
┌─┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7
💰 *Total:* ${dmt}
└─┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7┄1�7`)
}
handler.command = ['añadirdiamantes','addd','dard','dardiamantes'] 
handler.rowner = true
export default handler
