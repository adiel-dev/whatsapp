let handler = async (m, { conn, usedPrefix, text, command }) => {
let hash = text
if (m.quoted && m.quoted.fileSha256) hash = m.quoted.fileSha256.toString('hex')
if (!hash) throw `*🍒 Solo se Pueden Asignar Textos o Comandos Asignados a Stickers o Imagenes 🍒  Para Obtener el Código Asignado use el Comando ${usedPrefix}listcmd*`
let sticker = global.db.data.sticker
if (sticker[hash] && sticker[hash].locked) throw '*🍒 Solo el Owner Puede Realizar la Eliminación 🍒*'
delete sticker[hash]
m.reply(`*🔒 El Texto/Comando Asignado al Sticker/Imagen fue Eliminado de la Base de Datos Correctamente 🔒*`)}
handler.command = ['delcmd']
handler.rowner = true
export default handler
