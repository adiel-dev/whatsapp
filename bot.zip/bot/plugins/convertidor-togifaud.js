/* ********* */

let handler = async (m, { conn, usedPrefix, command }) => {
if (!m.quoted) throw `*🍒 Responda a un Video que Desee Convertir en Gif con Audio 🍒*`
const q = m.quoted || m
let mime = (q.msg || q).mimetype || ''
if (!/(mp4)/.test(mime)) throw `*⚔️ El tipo de Archivo ${mime} No es Correcto, Responda a un Video que Desee Convertir en Gif con Audio ⚔️*`
m.reply(global.wait)
let media = await q.download()
conn.sendMessage(m.chat, { video: media, gifPlayback: true, caption: '*🌴 Aquí esta su Gif con Audio, al Abrirlo se Reproduce 🌴*' }, { quoted: m })}
handler.command = ['togifaud']
export default handler
