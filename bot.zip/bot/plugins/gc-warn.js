let handler = async (m, { conn, text, command, usedPrefix }) => {
if (m.mentionedJid.includes(conn.user.jid)) return	
let pp = './src/warn.jpg'
let who
if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text
else who = m.chat
let user = global.db.data.users[who]
let bot = global.db.data.settings[conn.user.jid] || {}
let warntext = `*🩸 Etiquete a Una Persona o Responda a Un Mensaje del Grupo Para Advertir al Usuario 🩸*\n\n*—◉ Ejemplo:*\n*${usedPrefix + command} @${global.suittag}*`
if (!who) throw m.reply(warntext, m.chat, { mentions: conn.parseMention(warntext)}) 
user.warn += 1
  
await conn.sendButton(m.chat,`${user.warn == 1 ? `*@${who.split`@`[0]}*` : `*@${who.split`@`[0]}*`} Recibió Una Advertencia en Este Grupo`, `*ADVERTENCIAS ${user.warn}/3*\n\n${wm}`, pp, [['📋 ListWarn 📋', '#listwarn']], m, { mentions: [who] })
	
if (user.warn >= 3) {
if (!bot.restrict) return m.reply('*⚔️ El Propietario del Bot No tiene Habilitado las Restricciones (#enable restrict) Contacte con él Para que lo Habilite ⚔️*')        
user.warn = 0
await m.reply(`¡Te lo Advertí Varias Veces!\n*@${who.split`@`[0]}*🌩️ Superaste las *3* Advertencias, Ahora Serás Eliminado/a 🌩️`, null, { mentions: [who]})
//user.banned = true
await conn.groupParticipantsUpdate(m.chat, [who], 'remove') 
} 
return !1
}
handler.command = /^(advertir|advertencia|warn|warning)$/i
handler.group = true
handler.admin = true
handler.botAdmin = true
export default handler
