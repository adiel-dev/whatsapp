let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i

let handler = async (m, { conn, text, isMods, isOwner, isPrems }) => {
try {  
let link = (m.quoted ? m.quoted.text ? m.quoted.text : text : text) || text
let [_, code] = link.match(linkRegex) || []
if (!code) throw '*⚔️ Error, Link Erróneo o Faltante ⚔️*\n*👉🏻 Ingrese el Enlace de Un Grupo*\n\n*Ejemplo:*\n*#join https://chat.whatsapp.com/FwEUGxkvZD85fIIp0gKyhg*\n\n*⚔️ No Reponda a Ningún Mensaje, Puede Causar Interferencia, Escríbalo Únicamente Como Mensaje Nuevo ⚔️*'
if ( isPrems || isMods || isOwner || m.fromMe) {
let res = await conn.groupAcceptInvite(code)
await m.reply(`*🔥 El Bot se Unió con Éxito al Grupo, Disfrute del Bot 🔥*`)
} else {
const data = global.owner.filter(([id]) => id)
for (let jid of data.map(([id]) => [id] + '@s.whatsapp.net').filter(v => v != conn.user.jid)) await m.reply('*🍒 Nueva Solicitud del Bot Para Un Grupo 🍒*\n\n*—◉ Número del Solicitante:* ' + 'wa.me/' + m.sender.split('@')[0] + '\n*—◉ Link del Grupo Donde se Solicita el Bot:* ' + link, jid)
await m.reply('*🔗 El Link de su Grupo fue Enviado por Mi Propietario/a*\n\n*👉🏻 Su Grupo Estará en Evaluación y el Propietario/a del Bot Decidirá Si me Agrega o No*\n\n*🔒 Algunas de las Razones por la Cual su Solicitud Puede ser Rechazada Son:*\n*1.- El Bot Está Saturado*\n*2.- Se Eliminó Previamente el Bot del Grupo*\n*3.- El Link del Grupo fue Restablecido*\n*4.-El Bot no se Agrega a Grupos Por Decisión del Propietario/a*\n\n*👉🏻 Ten en Cuenta que tu Solicitud Para Unir el Bot a Un Grupo Puede Tardar Horas o Dias en ser Respondida, Ten Paciencia*')
}
} catch {
throw '*⚔️ Lo Sentimos, hay Un Error en Este Comando, Aun Trabajamos Para la Solución ⚔️*'  
}}
handler.help = ['join [chat.whatsapp.com]']
handler.tags = ['premium']
handler.command = /^join|nuevogrupo$/i
handler.private = true 
export default handler
